/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

public class BaseDatos {
    private final String url = "jdbc:derby://localhost:1527/ProyectoFinal";
    
    public Solicitar Solicitar(){
        return new Solicitar();
    }
    
    public Insertar Insertar(){
        Insertar ins= new Insertar();
        return ins;
    }
    
    public Actualizar Actualizar(){
        Actualizar act= new Actualizar();
        return act;
    }
        
    public String getUrl() {
    return url;
    }
}
