package Controlador;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LuisJimenez
 */
public class Registro {
    private String nombre;
    private String Apaterno;
    private String Amaterno;
    private String Fnac;
    private String mail;
    private String pass;

    public String getNombre() {
        return nombre;
    }

    public String getApaterno() {
        return Apaterno;
    }

    public String getAmaterno() {
        return Amaterno;
    }

    public String getFnac() {
        return Fnac;
    }

    public String getMail() {
        return mail;
    }

    public String getPass() {
        return pass;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApaterno(String Apaterno) {
        this.Apaterno = Apaterno;
    }

    public void setAmaterno(String Amaterno) {
        this.Amaterno = Amaterno;
    }

    public void setFnac(String Fnac) {
        this.Fnac = Fnac;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
        
}
