
import java.awt.Rectangle;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Luis Jiménez
 */
public class ShapeFactory {

    public Forma getShape(String shapeType) {
        if (shapeType == null) {
            return null;
        }

        if (shapeType.equalsIgnoreCase("CIRCLE")) {
            return new Circulo();
        } else if (shapeType.equalsIgnoreCase("RECTANGLE")) {
            return new Rectangulo();
        } else if (shapeType.equalsIgnoreCase("SQUARE")) {
            return  new Cuadrado();
        }
        return null;
    }

}
