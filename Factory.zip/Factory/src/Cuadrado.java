/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Luis Jiménez
 */
public class Cuadrado implements Forma{
    
     @Override
     public void draw() {
     System.out.println("Inside Cuadrado::Draw()method.");
    }
    
}
